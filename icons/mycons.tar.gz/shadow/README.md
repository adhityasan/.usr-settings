# Shadow
Linux icons with long shadow. 
See  https://rudrab.github.io/Shadow/

Also see [gnome-look](https://www.gnome-look.org/content/show.php/Shadow?content=170398),
maintained as a stable repo.
